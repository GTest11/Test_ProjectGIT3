#''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
# Author          :   Arathy P S
# Date            :   14-03-2018
# FE Version      :   5.0.9.4
# Description     :   This is a Library for config parameters
#''''''''''''''''''''AUTO GENERATED CODE - DO NOT MODIFY''''''''''''''''''''

ios_app_name = "com.bskyb.nowtv.intl.internal.gb"
ios_app_package = "com.bskyb.nowtv.beta"
ios_app_activity = "com.bskyb.nowtv.ui.activities.LaunchActivity"

android_app_package = "com.google.android.youtube"
android_app_activity = "com.google.android.youtube.HomeActivity"

app_home_checkpoint = "checkpoint name"
app_close_checkpoint = "checkpoint name"
